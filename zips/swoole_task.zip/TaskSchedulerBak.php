<?php

class TaskScheduler
{
    /**
     * @desc swoole客户端连接
     * @var swoole_client
     */
    protected $_swooleClient = null;

    /**
     * @desc swoole table
     * @var unknown
     */
    protected $_swooleTable = null;

    /**
     * @desc swoole服务协议
     * @var unknown
     */
    protected $_swooleProtocol = null;

    /**
     * @desc swoole服务主机地址
     * @var string
     */
    protected $_swooleServerHost = null;

    /**
     * @desc swoole服务端口
     * @var string
     */
    protected $_swooleServerPort = null;

    /**
     * @desc 任务对象
     * @var TaskAbstract
     */
    protected $_task = null;

    /**
     * @desc swoole服务配置参数
     * @var array
     */

    //protected $_swooleLock = null;

    protected $_swooleConfigs = [
        'worker_num' => 1,
        'task_worker_num' => 10,
        'daemonize' => false
    ];

    /**
     * @desc construct function
     * @param TaskAbstract $task
     * @param array $swooleConfigs
     */
    public function __construct($task, $swooleConfigs = [])
    {
        $this->_task = $task;
        $this->_swooleConfigs = array_merge($this->_swooleConfigs, $swooleConfigs);
        $serverKey = $this->_task->generateSwooleServerKey();
        //设置swoole日志记录路径
        $logPath = LOG_DIR . 'swoole';
        if (!file_exists($logPath))
            mkdir($logPath, '0777', true);
        $logName = $serverKey . '.log';
        $this->_swooleConfigs['log_file'] = $logPath . DIRECTORY_SEPARATOR . $logName;
    }

    /**
     * @desc 执行任务
     * @throws Exception
     */
    public function runTask()
    {
        try {
            //1.检查任务对应的swoole服务是否启动，没有启动则启动服务
            $this->checkSwooleServer();
            //2.连接swoole服务
            $this->_swooleClient = SwooleServerManager::connectionServer($this->_swooleServerHost, $this->_swooleServerPort);
            if (empty($this->_swooleClient))
                throw new Exception('Connection Swoole Server Failed');
            //3.发送任务到swoole服务器
            $this->sendTask($this->_task);
            return true;
        } catch (Exception $e) {
            echo date('c') . ' -- Run Task Exception, ' . var_export($e, true) . "\n";
        }
    }

    /**
     * @desc 发送任务请求到swoole服务
     * @param TaskAbstract $task
     */
    public function sendTask($task)
    {
        $taskData = serialize($task);
        $this->_swooleClient->send($taskData);
    }

    /**
     * @desc 检查swoole服务是否启动
     * @throws Exception
     */
    public function checkSwooleServer()
    {
        $serverKey = $this->_task->generateSwooleServerKey();
        //获取服务服务key对应的swoole服务信息
        $swooleServerModel = new SwooleServerModel();
        $swooleServerInfo = $swooleServerModel->findOne(['server_key' => $serverKey]);
        //没有相关swoole服务或者服务器没启动，启动swoole服务
        if (empty($swooleServerInfo)) {
            //保存swoole服务信息到mongodb
            $insertData = [
                'server_key' => $serverKey,
                'master_process_name' => '',
                'master_pid' => '',
                'manager_process_name' => '',
                'manager_pid' => '',
                'configs' => $this->_swooleConfigs,
                'create_time' => date('Y-m-d H:i:s'),
                'status' => SwooleServerManager::SERVER_UNKOWN,
                'update_time' => date('Y-m-d H:i:s'),
                'start_time' => '',
                'stop_time' => '',
                'host' => '',
                'port' => ''
            ];
            if (!$swooleServerModel->insertOne($insertData))
                throw new Exception('Save Swoole Server Faied');
            $masterPid = '';
        } else {
            $configs = $swooleServerInfo->configs;
            $masterPid = $swooleServerInfo->master_pid;
            $this->_swooleServerHost = $swooleServerInfo->host;
            $this->_swooleServerPort = $swooleServerInfo->port;
        }
        if (empty($masterPid) || !SwooleServerManager::serverIsRunning($swooleServerInfo['master_pid'])) {
            $server = SwooleServerManager::createSwooleServer($this->_swooleProtocol, $this->_swooleConfigs);
            if (!$server instanceof SwooleServer)
                throw new Exception('Instance Swoole Server Failed');
            $server->setProcessName($serverKey);
            //绑定swoole server事件
            $server->bindEvent(SwooleServer::EVENT_START, [$this, 'onStart']);
            $server->bindEvent(SwooleServer::EVENT_MANAGER_START, [$this, 'refreshServerInfo']);
            $server->bindEvent(SwooleServer::EVENT_TASK, [$this, 'onTask']);
            $server->bindEvent(SwooleServer::EVENT_FINISH, [$this, 'onFinish']);
            $server->bindEvent(SwooleServer::EVENT_RECEIVE, [$this, 'onReceive']);

            //创建swoole table解决任务并发问题
            $this->_swooleTable = new Swoole\Table(5120);
            $this->_swooleTable->column('timestamp', Swoole\Table::TYPE_INT);
            $this->_swooleTable->create();

            //$this->_swooleLock = new swoole_lock(SWOOLE_MUTEX);

            //启动服务
            if (!SwooleServerManager::launchServer($server))
                throw new Exception('Swoole Server Launch Failed');
        }
        return true;
    }

    /**
     * @desc 任务处理回调函数
     * @param unknown $server
     * @param unknown $taskId
     * @param unknown $srcWorkerId
     * @param unknown $data
     */
    public function onTask($server, $taskId, $srcWorkerId, $data)
    {
        //每个任务进程单独实例化mongodb类，解决mongodb多进程共享连接的bug
        try {
            $config = include CONFIG_DIR . ORG . '/mongodbConfig.php';
            $dsn = isset($config['dsn']) ? trim($config['dsn']) : '';
            $dbName = isset($config['db_name']) ? trim($config['db_name']) : '';
            $db = Db::getInstance()->createConnection($dsn, $dbName);
        } catch (Exception $e) {
            exit('Connection MongoDB Failed');
        }
        try {
            Front::registryGlobalVar('db', $db);
            //注册任务观察者
            $this->_task->registerTaskObserver();
            //注册任务处理程序
            $this->_task->registerTaskWorker();
            //@TODO task进程处理任务事件
            echo date('c') . ' -- TASK RUNNING NOW-TASK WORKER: ' . $taskId . ', TASK ID: ' . $data . "\n";
            $flag = $this->_task->runTask($data);
            echo date('c') . ' -- PULL ORDER RESULT: ' . $flag . "\n";
            $this->_task->notify();
            $server->getServer()->finish($data);
        } catch (Exception $e) {
            echo date('c') . ' -- ' . $e->getMessage() . "\n";
        }
    }

    /**
     * @desc 服务启动回调函数
     * @param unknown $server
     * @param unknown $taskId
     * @param unknown $srcWorkerId
     * @param unknown $data
     */
    public function onStart($server)
    {
        //@TODO 服务启动处理任务事件
        echo date('c') . ' -- Swoole Server Start' . "\n";

    }

    /**
     * @desc swoole服务接受到数据后回调函数
     * @param unknown $server
     * @param unknown $fd
     * @param unknown $reactorId
     * @param unknown $data
     * @return boolean
     */
    public function onReceive($server, $fd, $reactorId, $data)
    {
        echo date('c') . ' -- Receive Task ' . "\n";
        //@TODO task进程处理任务事件
        try {
            $task = unserialize($data);
            if (!$task instanceof TaskAbstract) {
                /*                 $server->getServer()->send($fd,
                                    'Server Except Accept Task Object，Other Type Accept'); */
                echo date('c') . ' -- Receive Task Exception, Task Type Error' . "\n";
                return false;
            }
            $this->_task = $task;
            $taskList = $task->getTaskList();
            if (is_array($taskList) && !empty($taskList)) {
                $taskModel = new TaskModel();
                foreach ($taskList as $taskId) {
                    //将任务修改为运行中
                    $this->deliverTask($server, $taskId);
                }
            } else {
                echo date('c') . ' -- No Task Received';
            }
        } catch (Exception $e) {
            echo date('c') . ' -- Receive Task Exception: ' . $e->getMessage() . "\n";
        }
    }

    /**
     * @desc 任务进程处理完任务后的回调函数
     * @param unknown $server
     * @param unknown $taskId
     * @param unknown $data
     */
    public function onFinish_BAK($server, $taskId, $data)
    {
        //@TODO task进程处理完任务事件
        echo date('c') . ' -- TASK FINISH NOW, TASK ID: ' . $data . "\n";
        //$this->_swooleTable->del($data);
        //获取下一个任务
        //查询正在运行中的任务，少于指定进程，则补发任务
        /*         $runningTasks = TaskModel::model()->getRunningTask($this->_task->platform,
                    $this->_task->type);
                $runningTaskNumber = sizeof($runningTasks); */
        $runningTaskNumber = 0;
        while (sizeof(TaskModel::model()->getRunningTask($this->_task->platform, $this->_task->type)) < $this->_task->thread) {
            $next = true;
            do {
                $taskId = $this->_task->getNextTask();
                //检查任务是否已经运行过
                try {
                    if (empty($taskId)) {
                        echo date('c') . ' -- NO TASK WAITING PROCESS' . "\n";
                        $next = false;
                        break 2;             //没有任务执行跳出外层循环
                    }
                    if (TaskQueueModel::model()->addTaskQueue([
                        'platform' => $this->_task->platform,
                        'type' => $this->_task->type,
                        'task_id' => $taskId
                    ])) {
                        //通过任务版本控制并发获取相同的任务
                        /*                    if ($this->_swooleTable->exist($taskId)) continue;
                                           $taskVersion = md5(uniqid(microtime(true), true));
                                           $this->_swooleTable->set($taskId, ['version' => $taskVersion]);
                                           $data = $this->_swooleTable->get($taskId);
                                           if ($data['version'] != $taskVersion)
                                           {
                                               echo date('c') . ' -- TASK "' . $taskId . '" DUPLICATE' . "\n";
                                               continue;
                                           } */
                        $server->getServer()->task($taskId);
                        $next = false;
                    }
                } catch (Exception $e) {
                    echo date('c') . ' -- TASK "' . $taskId . '" ADD TASK QUEUE EXCEPTION' .
                        $e->getMessage() . "\n";
                }
            } while ($next);
            $runningTaskNumber++;
        }
    }

    /**
     * @desc 任务进程处理完任务后的回调函数
     * @param unknown $server
     * @param unknown $taskId
     * @param unknown $data
     */
    public function onFinish($server, $taskId, $data)
    {
        //@TODO task进程处理完任务事件
        echo date('c') . ' -- TASK FINISH NOW, TASK ID: ' . $data . "\n";
        //从内存中删除完成的任务
        //$this->_swooleTable->del($data);
        while (sizeof(TaskModel::model()->getRunningTask($this->_task->platform,
                $this->_task->type)) < $this->_task->thread) {
            //echo date('c') . ' -- TASK ID: ' . $data . " WAITING LOCK\n";
            //$startTime = microtime(true);
            //$this->_swooleLock->lock();
            //echo date('c') . ' -- TASK ID: ' . $data . " GET LOCK, \n";
            //重试次数
            $retry = 10;
            $next = true;
            do {
                $taskId = $this->_task->getNextTask();
                if (empty($taskId)) {
                    echo date('c') . ' -- NO TASK WAITING PROCESS' . "\n";
                    break 2;
                }
                //$key = strval($taskId);
                //检查任务是否已经运行过
                //$cacheData = $this->_swooleTable->get($key);
                //运行过超时（10秒），重新投递
                //if (empty($cacheData) || $cacheData['timestamp'] + 10 < time() )
                //{
                //$this->_swooleTable->set($key, [time()]);
                //将任务修改为运行中
                /*                     $taskModel = new TaskModel();
                                    $criteria = ['_id'=> $taskId];
                                    $flag = $taskModel->updateOne($criteria, [
                                        'status' => TaskModel::STATUS_RUNNING,
                                        'execute_time' => date('Y-m-d H:i:s')
                                    ]);
                                    if ($flag)
                                    {
                                        //投递任务
                                        $swooleTaskId = $server->getServer()->task($taskId);
                                        if (!$swooleTaskId)
                                        {
                                            $flag = $taskModel->updateOne($criteria, [
                                                'status' => TaskModel::STATUS_INIT,
                                                'execute_time' => ''
                                            ]);
                                        }
                                        else
                                          $next = false;

                                    } */
                if ($this->deliverTask($server, $taskId))
                    $next = false;
                //}
                //else
                //{
                //echo date('c') . ' -- TASK ID "' . $taskId . '" EXISTS' . "\n";
                //}


            } while ($next && $retry--);
            //$this->_swooleLock->unlock();
            //$endTime = microtime(true);
            //echo date('c') . ' -- TASK ID: ' . $data . " RELEASE LOCK, TIME " . ($endTime - $startTime) . "\n";
        }
    }

    /**
     * @desc deliver task
     * @param unknown $server
     * @param unknown $taskId
     * @return boolean
     */
    public function deliverTask($server, $taskId)
    {
        $taskModel = new TaskModel();
        if (is_string($taskId))
            $taskId = new MongoDB\BSON\ObjectId($taskId);
        //检查任务是否运行中
        $criteria = ['_id' => $taskId];
        $taskInfo = $taskModel->findOne($criteria);
        if (!empty($taskInfo) && $taskInfo['status'] == TaskModel::STATUS_RUNNING)
            return false;
        //将任务更新为运行中
        $flag = $taskModel->updateOne($criteria, ['status' => TaskModel::STATUS_RUNNING, 'execute_time' => date('Y-m-d H:i:s')]);
        if ($flag) {
            //投递任务
            $swooleTaskId = $server->getServer()->task($taskId);
            if (!$swooleTaskId) {
                //投递失败将任务更新为初始化
                $flag = $taskModel->updateOne($criteria, ['status' => TaskModel::STATUS_INIT, 'execute_time' => '']);
            } else
                return true;

        }
        return false;
    }

    /**
     * @desc 更新swoole服务信息到mongodb数据库
     * @param SwooleServer $server
     * @return boolean
     */
    public function refreshServerInfo(SwooleServer $server = null)
    {
        $serverKey = $this->_task->generateSwooleServerKey();
        $swooleServerModel = new SwooleServerModel();
        $swooleServerInfo = $swooleServerModel->findOne(['server_key' => $serverKey]);
        if (!empty($swooleServerInfo)) {
            $filter = [
                '_id' => $swooleServerInfo->_id
            ];
            $updateData = [
                'master_process_name' => $server->getMasterProcessName(),
                'manager_process_name' => $server->getManagerProcessName(),
                'master_pid' => $server->getMasterPid(),
                'manager_pid' => $server->getManagerPid(),
                'port' => $server->getPort(),
                'host' => $server->getHost(),
                'status' => SwooleServerManager::SERVER_RUNNING,
                'update_time' => date('Y-m-d H:i:s'),
                'start_time' => date('Y-m-d H:i:s'),
                'error_code' => $server->getLastError()
            ];
            return $swooleServerModel->updateOne($filter, $updateData);
        }
        return false;
    }
}